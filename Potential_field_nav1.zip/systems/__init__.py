#!/usr/bin/env python3
"""
Robot Systems Package
Contains all robot subsystems including sensors, movement, control, and navigation
"""

# This file makes the systems directory a Python package