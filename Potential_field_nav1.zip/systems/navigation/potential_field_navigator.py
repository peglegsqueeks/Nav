#!/usr/bin/env python3
"""
Potential Field Navigation System - FIXED DIRECTION BUG
Main navigation controller that integrates person detection, obstacle avoidance,
and robot movement using potential field mathematics
FIXED: Deque slice indexing error in get_navigation_status()
FIXED: Movement direction now correctly uses robot-relative coordinates
"""
import time
import math
from collections import deque
from typing import Optional, Dict, Any, List, Tuple

from .field_calculations import PotentialFieldCalculations
from .navigation_state_machine import NavigationStateMachine

class PotentialFieldNavigator:
    """
    Main potential field navigation controller - FIXED DIRECTION VERSION
    Coordinates person detection, obstacle avoidance, and robot movement
    """
    
    def __init__(self):
        # Core systems
        self.field_calculator = PotentialFieldCalculations()
        self.state_machine = NavigationStateMachine()
        
        # Navigation state
        self.navigation_enabled = False
        self.person_target = None  # Current person target position
        self.last_person_update = 0.0
        self.person_timeout = 3.0  # seconds - lose target if no updates
        
        # Robot state tracking
        self.robot_position = {'x': 0.0, 'y': 0.0, 'orientation': 0.0}
        self.position_history = deque(maxlen=50)
        
        # Navigation performance
        self.navigation_start_time = 0.0
        self.total_navigation_time = 0.0
        self.successful_navigations = 0
        self.failed_navigations = 0
        self.goals_reached = 0
        
        # Force tracking
        self.current_forces = {
            'attractive': (0.0, 0.0),
            'repulsive': (0.0, 0.0),
            'total': (0.0, 0.0)
        }
        
        # Movement command tracking
        self.current_movement_command = None
        self.last_movement_time = 0.0
        self.movement_command_history = deque(maxlen=20)
        
        # Safety and performance monitoring
        self.stuck_detection_enabled = True
        self.stuck_threshold_time = 8.0  # seconds
        self.last_significant_movement = time.time()
        self.min_movement_distance = 30.0  # mm
        
        # Debug and analysis
        self.debug_enabled = False
        self.navigation_log = []
    
    def update_robot_state(self, robot_state: Dict[str, Any]):
        """Update robot position and orientation from robot state tracker"""
        try:
            self.robot_position = {
                'x': robot_state.get('position_x', 0.0),
                'y': robot_state.get('position_y', 0.0), 
                'orientation': robot_state.get('orientation', 0.0)
            }
            
            # Add to position history for stuck detection
            current_time = time.time()
            self.position_history.append({
                'x': self.robot_position['x'],
                'y': self.robot_position['y'],
                'timestamp': current_time
            })
            
            # Check for significant movement
            if len(self.position_history) >= 2:
                prev_pos = self.position_history[-2]
                dx = self.robot_position['x'] - prev_pos['x']
                dy = self.robot_position['y'] - prev_pos['y']
                distance_moved = math.sqrt(dx**2 + dy**2)
                
                if distance_moved > self.min_movement_distance:
                    self.last_significant_movement = current_time
                    
        except Exception as e:
            if self.debug_enabled:
                print(f"Error updating robot state: {e}")
    
    def update_person_target(self, person_data: Optional[Dict[str, Any]], 
                           lidar_distance: float, lidar_angle: float):
        """Update current person target from detection system"""
        try:
            current_time = time.time()
            
            if person_data and lidar_distance > 0:
                # Convert polar coordinates to cartesian (relative to robot)
                angle_rad = math.radians(lidar_angle)
                person_x = self.robot_position['x'] + lidar_distance * math.cos(angle_rad)
                person_y = self.robot_position['y'] + lidar_distance * math.sin(angle_rad)
                
                self.person_target = {
                    'x': person_x,
                    'y': person_y,
                    'distance': lidar_distance,
                    'angle': lidar_angle,
                    'confidence': person_data.get('confidence', 0.0),
                    'timestamp': current_time
                }
                
                self.last_person_update = current_time
                
                if self.debug_enabled:
                    print(f"Person target updated: ({person_x:.1f}, {person_y:.1f}) at {lidar_distance:.0f}mm")
            else:
                # Check if target has timed out
                if current_time - self.last_person_update > self.person_timeout:
                    if self.person_target:
                        if self.debug_enabled:
                            print("Person target lost (timeout)")
                    self.person_target = None
                    
        except Exception as e:
            if self.debug_enabled:
                print(f"Error updating person target: {e}")
    
    def calculate_navigation_forces(self, obstacles: List[Tuple[float, float]]) -> Dict[str, Tuple[float, float]]:
        """Calculate attractive and repulsive forces for navigation"""
        try:
            attractive_force = (0.0, 0.0)
            repulsive_force = (0.0, 0.0)
            
            robot_x = self.robot_position['x']
            robot_y = self.robot_position['y']
            
            # Calculate attractive force towards person
            if self.person_target:
                attractive_force = self.field_calculator.calculate_attractive_field(
                    robot_x, robot_y,
                    self.person_target['x'], self.person_target['y']
                )
            
            # Calculate repulsive forces from obstacles
            if obstacles:
                repulsive_force = self.field_calculator.calculate_repulsive_field(
                    robot_x, robot_y, obstacles
                )
            
            # Sum forces
            total_force = self.field_calculator.sum_force_vectors(
                attractive_force, repulsive_force
            )
            
            # Store current forces
            self.current_forces = {
                'attractive': attractive_force,
                'repulsive': repulsive_force,
                'total': total_force
            }
            
            return self.current_forces
            
        except Exception as e:
            if self.debug_enabled:
                print(f"Error calculating navigation forces: {e}")
            return {
                'attractive': (0.0, 0.0),
                'repulsive': (0.0, 0.0),
                'total': (0.0, 0.0)
            }
    
    def generate_movement_command(self):
        """Generate movement command from current forces - FIXED DIRECTION"""
        try:
            if not self.navigation_enabled:
                return None
            
            total_force = self.current_forces['total']
            
            # FIXED: Use orientation = 0.0 because forces are already calculated in 
            # robot-relative coordinates (based on LiDAR angle where 0 = directly in front).
            # The force direction from calculate_attractive_field is determined by the 
            # LiDAR angle offset (person_x - robot_x, person_y - robot_y), which equals
            # (distance * cos(lidar_angle), distance * sin(lidar_angle)).
            # This is already robot-relative, so we don't need IMU orientation adjustment.
            direction_str, speed = self.field_calculator.convert_force_to_velocity(
                total_force[0], total_force[1], 0.0
            )
            
            # Create movement command
            if direction_str != "NONE" and speed > 0:
                command = {
                    'direction': direction_str,
                    'speed': speed
                }
                
                # Track command
                current_time = time.time()
                self.current_movement_command = {
                    'direction': direction_str,
                    'speed': speed,
                    'timestamp': current_time,
                    'force_magnitude': math.sqrt(total_force[0]**2 + total_force[1]**2)
                }
                
                self.movement_command_history.append(self.current_movement_command)
                self.last_movement_time = current_time
                
                if self.debug_enabled:
                    print(f"Movement command: {direction_str} at {speed:.2f}")
                
                return command
            else:
                # No movement needed
                self.current_movement_command = None
                return None
                
        except Exception as e:
            if self.debug_enabled:
                print(f"Error generating movement command: {e}")
            return None
    
    def check_goal_reached(self) -> bool:
        """Check if navigation goal has been reached"""
        try:
            if not self.person_target:
                return False
            
            goal_reached = self.field_calculator.is_goal_reached(
                self.robot_position['x'], self.robot_position['y'],
                self.person_target['x'], self.person_target['y']
            )
            
            if goal_reached and self.navigation_enabled:
                self.goals_reached += 1
                if self.debug_enabled:
                    print("Navigation goal reached!")
                return True
                
            return False
            
        except Exception as e:
            if self.debug_enabled:
                print(f"Error checking goal reached: {e}")
            return False
    
    def check_stuck_condition(self) -> bool:
        """Check if robot is stuck in local minimum or not making progress"""
        try:
            if not self.stuck_detection_enabled:
                return False
            
            current_time = time.time()
            
            # Check if robot hasn't moved significantly in a while
            time_since_movement = current_time - self.last_significant_movement
            if time_since_movement > self.stuck_threshold_time:
                if self.debug_enabled:
                    print(f"Robot appears stuck - no significant movement for {time_since_movement:.1f}s")
                return True
            
            # Check position history for local minimum detection
            if len(self.position_history) >= 10:
                # FIXED: Convert deque to list before slicing
                recent_positions = [(pos['x'], pos['y']) for pos in list(self.position_history)[-10:]]
                if self.field_calculator.check_local_minimum(recent_positions):
                    if self.debug_enabled:
                        print("Robot detected in local minimum")
                    return True
            
            return False
            
        except Exception as e:
            if self.debug_enabled:
                print(f"Error checking stuck condition: {e}")
            return False
    
    def enable_navigation(self):
        """Enable autonomous navigation"""
        if not self.navigation_enabled:
            self.navigation_enabled = True
            self.navigation_start_time = time.time()
            self.state_machine.start_navigation()
            
            if self.debug_enabled:
                print("Navigation ENABLED")
    
    def disable_navigation(self):
        """Disable autonomous navigation"""
        if self.navigation_enabled:
            self.navigation_enabled = False
            if self.navigation_start_time > 0:
                self.total_navigation_time += time.time() - self.navigation_start_time
                self.navigation_start_time = 0
            
            self.state_machine.stop_navigation()
            self.current_movement_command = None
            
            if self.debug_enabled:
                print("Navigation DISABLED")
    
    def get_navigation_status(self) -> Dict[str, Any]:
        """Get comprehensive navigation status - FIXED SLICE INDEXING"""
        try:
            # Check state machine
            try:
                current_state = self.state_machine.get_current_state()
            except Exception:
                current_state = "ERROR"
            
            # Check field calculator
            try:
                force_stats = self.field_calculator.get_force_statistics()
            except Exception:
                force_stats = {
                    'calculation_count': 0,
                    'avg_attractive_magnitude': 0.0,
                    'avg_repulsive_magnitude': 0.0,
                    'avg_total_magnitude': 0.0
                }
            
            # Check goal reached
            try:
                goal_reached = self.check_goal_reached()
            except Exception:
                goal_reached = False
            
            # Calculate navigation performance metrics
            try:
                total_navigations = self.successful_navigations + self.failed_navigations
                success_rate = (self.successful_navigations / max(1, total_navigations)) * 100
            except Exception:
                success_rate = 0.0
            
            # FIXED: Check movement command history with proper deque handling
            try:
                avg_command_interval = 0.0
                if len(self.movement_command_history) > 1:
                    # FIXED: Convert deque to list before slicing
                    recent_commands = list(self.movement_command_history)[-10:]
                    times = [cmd['timestamp'] for cmd in recent_commands]
                    if len(times) > 1:
                        intervals = [times[i+1] - times[i] for i in range(len(times)-1)]
                        avg_command_interval = sum(intervals) / len(intervals)
            except Exception:
                avg_command_interval = 0.0
            
            # Build status dict
            try:
                status = {
                    # Navigation state
                    'navigation_enabled': self.navigation_enabled,
                    'current_state': current_state,
                    'has_person_target': self.person_target is not None,
                    'goal_reached': goal_reached,
                    'robot_stuck': self.check_stuck_condition(),
                    
                    # Target information
                    'person_distance': self.person_target['distance'] if self.person_target else 0.0,
                    'person_angle': self.person_target['angle'] if self.person_target else 0.0,
                    'time_since_person_update': time.time() - self.last_person_update,
                    
                    # Force information
                    'attractive_force_magnitude': math.sqrt(sum(x**2 for x in self.current_forces['attractive'])),
                    'repulsive_force_magnitude': math.sqrt(sum(x**2 for x in self.current_forces['repulsive'])),
                    'total_force_magnitude': math.sqrt(sum(x**2 for x in self.current_forces['total'])),
                    
                    # Movement information
                    'current_movement_direction': self.current_movement_command['direction'] if self.current_movement_command else 'NONE',
                    'current_movement_speed': self.current_movement_command['speed'] if self.current_movement_command else 0.0,
                    'time_since_last_movement': time.time() - self.last_movement_time if self.last_movement_time > 0 else 0,
                    
                    # Performance metrics
                    'successful_navigations': self.successful_navigations,
                    'failed_navigations': self.failed_navigations,
                    'goals_reached': self.goals_reached,
                    'navigation_success_rate': success_rate,
                    'total_navigation_time': self.total_navigation_time,
                    'avg_movement_command_interval': avg_command_interval,
                    
                    # Force statistics
                    'force_calculations_count': force_stats['calculation_count'],
                    'avg_attractive_magnitude': force_stats['avg_attractive_magnitude'],
                    'avg_repulsive_magnitude': force_stats['avg_repulsive_magnitude'],
                    'avg_total_force_magnitude': force_stats['avg_total_magnitude'],
                    
                    # Field parameters
                    'attractive_strength': self.field_calculator.attractive_strength,
                    'repulsive_strength': self.field_calculator.repulsive_strength,
                    'goal_reached_threshold': self.field_calculator.goal_reached_threshold,
                }
                
                return status
                
            except Exception as e:
                # Return minimal error status if status building fails
                return {
                    'navigation_enabled': False, 
                    'current_state': 'ERROR',
                    'has_person_target': False,
                    'goal_reached': False,
                    'robot_stuck': True,
                    'person_distance': 0.0,
                    'person_angle': 0.0,
                    'time_since_person_update': 0,
                    'attractive_force_magnitude': 0.0,
                    'repulsive_force_magnitude': 0.0,
                    'total_force_magnitude': 0.0,
                    'current_movement_direction': 'NONE',
                    'current_movement_speed': 0.0,
                    'time_since_last_movement': 0,
                    'successful_navigations': 0,
                    'failed_navigations': 0,
                    'goals_reached': 0,
                    'navigation_success_rate': 0.0,
                    'total_navigation_time': 0.0,
                    'avg_movement_command_interval': 0.0,
                    'force_calculations_count': 0,
                    'avg_attractive_magnitude': 0.0,
                    'avg_repulsive_magnitude': 0.0,
                    'avg_total_force_magnitude': 0.0,
                    'attractive_strength': 0.0,
                    'repulsive_strength': 0.0,
                    'goal_reached_threshold': 0.0
                }
                
        except Exception as e:
            # Fallback minimal status
            return {'navigation_enabled': False, 'current_state': 'ERROR'}
    
    def update_navigation_state(self, person_data: Optional[Dict[str, Any]], 
                              obstacles: List[Tuple[float, float]]) -> str:
        """Update navigation state machine based on current conditions"""
        try:
            # Update state machine with current conditions
            has_person = person_data is not None and self.person_target is not None
            goal_reached = self.check_goal_reached() if has_person else False
            is_stuck = self.check_stuck_condition()
            has_obstacles = len(obstacles) > 0
            
            return self.state_machine.update_state(
                has_person_target=has_person,
                goal_reached=goal_reached,
                robot_stuck=is_stuck,
                obstacles_detected=has_obstacles,
                navigation_enabled=self.navigation_enabled
            )
            
        except Exception as e:
            if self.debug_enabled:
                print(f"Error updating navigation state: {e}")
            return "ERROR"
    
    def set_debug_mode(self, enabled: bool):
        """Enable/disable debug output"""
        self.debug_enabled = enabled
        
    def reset_navigation_statistics(self):
        """Reset navigation performance statistics"""
        self.successful_navigations = 0
        self.failed_navigations = 0
        self.goals_reached = 0
        self.total_navigation_time = 0.0
        self.navigation_log.clear()
        
        if self.debug_enabled:
            print("Navigation statistics reset")